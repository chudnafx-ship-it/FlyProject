# Fly Project (Flutter 3)

A high-performance tournament, club, and academic member management application built using **Flutter 3**, **Material Design 3**, and **Cloud Firestore**.

> **Important Notice:**  
> This application is strictly an educational, athletic, and administrative tool for managing tournament brackets, clubs, and team rosters utilizing a computer science **Binary Tree** data structure.  
> The "Points" displayed are purely virtual integers (0–999,999) used for score tracking and ranking. Points have no monetary value, cannot be transferred, redeemed, cashed out, or exchanged for currency or physical rewards.

---

## Features

- **Binary Tree Data Structure:**
  - Every member node has at most two children (`LEFT` and `RIGHT`).
  - Interactive pan-and-zoom visual canvas with smooth Bézier curve connectors.
  - Public read-only visualization for players and visitors.
- **Member Attributes:**
  - **Full Name**
  - **User ID:** Strictly enforced format `A00001` to `A99999`.
  - **Virtual Points:** Integers between `0` and `999,999` for tournament scoring.
  - **Join Date** & Position tracking.
- **Administrative Security:**
  - Public tree viewer (no authentication required to browse the tree or directory).
  - Admin mode gated by a secure Admin PIN.
  - Only authenticated admins can add members, edit virtual points, or remove members.
- **Real-time Backend:**
  - Powered by Google Cloud Firestore with real-time stream synchronization.
  - Atomic transactions for slot assignment and tree integrity.
- **Search & Navigation:**
  - Real-time search by User ID (e.g. `A00001`) or Member Name.
  - Dual-view interface: Interactive Tree Canvas vs. Hierarchical Directory List.

---

## Project Structure

```
flutter_project/
├── pubspec.yaml                 # Dependencies and assets
├── README.md                    # Documentation
├── .gitignore                   # Standard Flutter gitignore
└── lib/
    ├── main.dart                # Entrypoint & Material 3 theme
    ├── models/
    │   └── member.dart          # Member model with validation & slot logic
    ├── services/
    │   └── firestore_service.dart # Cloud Firestore streams & atomic operations
    ├── screens/
    │   └── main_screen.dart     # Main view with Tree & Directory tabs
    └── widgets/
        ├── binary_tree_view.dart    # Custom Bézier branch painter & interactive canvas
        ├── member_card.dart         # Material 3 node component with status chips
        ├── member_detail_sheet.dart # Bottom sheet with member details & admin actions
        ├── add_member_dialog.dart   # Slot-validated member creation dialog
        ├── edit_points_dialog.dart  # Clamped (0-999,999) score editor
        ├── admin_pin_dialog.dart    # PIN verification modal
        └── hierarchy_list_view.dart # Indented directory list grouped by levels
```

---

## Getting Started

### Prerequisites

- [Flutter SDK](https://flutter.dev/docs/get-started/install) (3.10.0 or later)
- Android Studio or VS Code with Flutter extensions
- A Firebase project with Cloud Firestore enabled

### Installation & Run

1. Clone or download this repository:
   ```bash
   git clone https://github.com/<your-username>/FlyProject.git
   cd FlyProject
   ```

2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Configure Firebase:
   Run the FlutterFire CLI to link your Firebase project:
   ```bash
   flutterfire configure
   ```
   Or place your `google-services.json` in `android/app/` and `GoogleService-Info.plist` in `ios/Runner/`.

4. Run the app:
   ```bash
   flutter run
   ```
