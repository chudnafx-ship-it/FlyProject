import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/member.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  late final CollectionReference _membersRef;

  FirestoreService() {
    _membersRef = _db.collection('members');
  }

  Stream<List<Member>> streamMembers() {
    return _membersRef.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => Member.fromFirestore(doc)).toList();
    });
  }

  Future<List<Member>> getAllMembersOnce() async {
    final snapshot = await _membersRef.get();
    return snapshot.docs.map((doc) => Member.fromFirestore(doc)).toList();
  }

  Future<String> addMember({
    required String userId,
    required String name,
    required int points,
    String? parentId,
    String? position,
  }) async {
    final cleanUserId = userId.trim().toUpperCase();
    final cleanName = name.trim();
    final clampedPoints = points.clamp(Member.minPoints, Member.maxPoints);

    if (cleanUserId.isEmpty) throw ArgumentError('User ID cannot be blank');
    if (cleanName.isEmpty) throw ArgumentError('Name cannot be blank');

    final newDoc = _membersRef.doc();
    final newMemberId = newDoc.id;

    if (parentId != null && parentId.isNotEmpty) {
      final validPosition = position ?? Member.positionLeft;
      final parentRef = _membersRef.doc(parentId);

      await _db.runTransaction((transaction) async {
        final parentSnapshot = await transaction.get(parentRef);
        if (!parentSnapshot.exists) {
          throw StateError('Selected parent member no longer exists.');
        }

        final parentData = parentSnapshot.data() as Map<String, dynamic>? ?? {};
        final existingChildId = validPosition == Member.positionLeft
            ? parentData['leftChildId']
            : parentData['rightChildId'];

        if (existingChildId != null && existingChildId.toString().isNotEmpty) {
          throw StateError('Parent already has a $validPosition child.');
        }

        transaction.set(newDoc, {
          'userId': cleanUserId,
          'name': cleanName,
          'points': clampedPoints,
          'parentId': parentId,
          'position': validPosition,
          'leftChildId': null,
          'rightChildId': null,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });

        final updateField = validPosition == Member.positionLeft ? 'leftChildId' : 'rightChildId';
        transaction.update(parentRef, {
          updateField: newMemberId,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
    } else {
      // Root Member
      await newDoc.set({
        'userId': cleanUserId,
        'name': cleanName,
        'points': clampedPoints,
        'parentId': null,
        'position': null,
        'leftChildId': null,
        'rightChildId': null,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    return newMemberId;
  }

  Future<void> updatePoints(String memberId, int newPoints) async {
    final clamped = newPoints.clamp(Member.minPoints, Member.maxPoints);
    await _membersRef.doc(memberId).update({
      'points': clamped,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateMember(String memberId, String name, int points) async {
    final cleanName = name.trim();
    final clamped = points.clamp(Member.minPoints, Member.maxPoints);
    await _membersRef.doc(memberId).update({
      'name': cleanName,
      'points': clamped,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> removeMember(String memberId, {bool cascade = true}) async {
    final memberDoc = await _membersRef.doc(memberId).get();
    if (!memberDoc.exists) return;

    final member = Member.fromFirestore(memberDoc);
    final allMembers = await getAllMembersOnce();
    final map = {for (var m in allMembers) m.id: m};

    final idsToDelete = <String>{};
    if (cascade) {
      void collectDescendants(String id) {
        idsToDelete.add(id);
        final m = map[id];
        if (m == null) return;
        if (m.leftChildId != null) collectDescendants(m.leftChildId!);
        if (m.rightChildId != null) collectDescendants(m.rightChildId!);
      }
      collectDescendants(memberId);
    } else {
      idsToDelete.add(memberId);
    }

    final batch = _db.batch();

    // Update parent link
    if (member.parentId != null && member.parentId!.isNotEmpty) {
      final parent = map[member.parentId];
      if (parent != null && !idsToDelete.contains(parent.id)) {
        final parentRef = _membersRef.doc(parent.id);
        if (parent.leftChildId == memberId) {
          batch.update(parentRef, {
            'leftChildId': null,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        } else if (parent.rightChildId == memberId) {
          batch.update(parentRef, {
            'rightChildId': null,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      }
    }

    // Unlink children if not cascading
    if (!cascade) {
      if (member.leftChildId != null) {
        batch.update(_membersRef.doc(member.leftChildId), {
          'parentId': null,
          'position': null,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
      if (member.rightChildId != null) {
        batch.update(_membersRef.doc(member.rightChildId), {
          'parentId': null,
          'position': null,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    }

    for (final id in idsToDelete) {
      batch.delete(_membersRef.doc(id));
    }

    await batch.commit();
  }

  Future<void> seedInitialDataIfEmpty() async {
    final existing = await _membersRef.limit(1).get();
    if (existing.docs.isNotEmpty) return;

    final batch = _db.batch();
    final rootId = _membersRef.doc().id;
    final bId = _membersRef.doc().id;
    final cId = _membersRef.doc().id;
    final dId = _membersRef.doc().id;
    final eId = _membersRef.doc().id;
    final fId = _membersRef.doc().id;
    final gId = _membersRef.doc().id;

    // Root A00001
    batch.set(_membersRef.doc(rootId), {
      'userId': 'A00001',
      'name': 'Alexander Wright',
      'points': 850000,
      'parentId': null,
      'position': null,
      'leftChildId': bId,
      'rightChildId': cId,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // Left child: A00002
    batch.set(_membersRef.doc(bId), {
      'userId': 'A00002',
      'name': 'Beatrice Vance',
      'points': 620000,
      'parentId': rootId,
      'position': Member.positionLeft,
      'leftChildId': dId,
      'rightChildId': eId,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // Right child: A00003
    batch.set(_membersRef.doc(cId), {
      'userId': 'A00003',
      'name': 'Charles Montgomery',
      'points': 740000,
      'parentId': rootId,
      'position': Member.positionRight,
      'leftChildId': fId,
      'rightChildId': gId,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // A00004
    batch.set(_membersRef.doc(dId), {
      'userId': 'A00004',
      'name': 'David Miller',
      'points': 310500,
      'parentId': bId,
      'position': Member.positionLeft,
      'leftChildId': null,
      'rightChildId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // A00005
    batch.set(_membersRef.doc(eId), {
      'userId': 'A00005',
      'name': 'Elena Rostova',
      'points': 495000,
      'parentId': bId,
      'position': Member.positionRight,
      'leftChildId': null,
      'rightChildId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // A00006
    batch.set(_membersRef.doc(fId), {
      'userId': 'A00006',
      'name': 'Fiona Gallagher',
      'points': 280000,
      'parentId': cId,
      'position': Member.positionLeft,
      'leftChildId': null,
      'rightChildId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    // A00007
    batch.set(_membersRef.doc(gId), {
      'userId': 'A00007',
      'name': 'George Sterling',
      'points': 510000,
      'parentId': cId,
      'position': Member.positionRight,
      'leftChildId': null,
      'rightChildId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }
}
