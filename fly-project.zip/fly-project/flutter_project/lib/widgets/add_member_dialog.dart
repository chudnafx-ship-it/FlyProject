import 'package:flutter/material.dart';
import '../models/member.dart';

class AddMemberDialog extends StatefulWidget {
  final Member? initialParent;
  final String? initialPosition;
  final List<Member> parentCandidates;
  final String suggestedUserId;
  final bool isTreeEmpty;
  final Function({
    required String name,
    required String userId,
    required int points,
    String? parentId,
    String? position,
  }) onConfirm;

  const AddMemberDialog({
    super.key,
    this.initialParent,
    this.initialPosition,
    required this.parentCandidates,
    required this.suggestedUserId,
    required this.isTreeEmpty,
    required this.onConfirm,
  });

  @override
  State<AddMemberDialog> createState() => _AddMemberDialogState();
}

class _AddMemberDialogState extends State<AddMemberDialog> {
  final _nameController = TextEditingController();
  late final TextEditingController _userIdController;
  final _pointsController = TextEditingController(text: '1000');

  String? _selectedParentId;
  String? _selectedPosition;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _userIdController = TextEditingController(text: widget.suggestedUserId);
    _selectedParentId = widget.initialParent?.id ??
        (widget.parentCandidates.isNotEmpty ? widget.parentCandidates.first.id : null);
    _selectedPosition = widget.initialPosition ?? Member.positionLeft;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _userIdController.dispose();
    _pointsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final candidate = widget.parentCandidates.firstWhere(
      (c) => c.id == _selectedParentId,
      orElse: () => Member(id: '', userId: '', name: '', points: 0),
    );

    final leftOpen = candidate.leftChildId == null;
    final rightOpen = candidate.rightChildId == null;

    return AlertDialog(
      title: Text(widget.isTreeEmpty ? 'Add Root Member' : 'Add Binary Tree Member'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Full Name *',
                hintText: 'e.g. Jessica Taylor',
              ),
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _userIdController,
              decoration: const InputDecoration(
                labelText: 'User ID (e.g. A00001) *',
                helperText: 'Format: Letter + 5 digits (A00001 - Z99999)',
              ),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _pointsController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Initial Points (0 - 999,999) *',
                helperText: 'Max allowable: 999,999 points',
              ),
            ),
            if (!widget.isTreeEmpty) ...[
              const SizedBox(height: 16),
              const Text(
                'Hierarchy Placement',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _selectedParentId,
                decoration: const InputDecoration(
                  labelText: 'Parent Member',
                  border: OutlineInputBorder(),
                ),
                items: widget.parentCandidates.map((m) {
                  return DropdownMenuItem(
                    value: m.id,
                    child: Text('${m.name} (${m.userId})'),
                  );
                }).toList(),
                onChanged: (val) {
                  setState(() {
                    _selectedParentId = val;
                  });
                },
              ),
              const SizedBox(height: 12),
              const Text(
                'Position (Each member can have only 2 children)',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: ChoiceChip(
                      label: const Text('Left Child'),
                      selected: _selectedPosition == Member.positionLeft,
                      onSelected: leftOpen
                          ? (selected) {
                              if (selected) setState(() => _selectedPosition = Member.positionLeft);
                            }
                          : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ChoiceChip(
                      label: const Text('Right Child'),
                      selected: _selectedPosition == Member.positionRight,
                      onSelected: rightOpen
                          ? (selected) {
                              if (selected) setState(() => _selectedPosition = Member.positionRight);
                            }
                          : null,
                    ),
                  ),
                ],
              ),
            ],
            if (_errorMessage != null) ...[
              const SizedBox(height: 12),
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.red, fontSize: 12),
              ),
            ]
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _handleSubmit,
          child: const Text('Add to Tree'),
        ),
      ],
    );
  }

  void _handleSubmit() {
    final name = _nameController.text.trim();
    final userId = _userIdController.text.trim().toUpperCase();
    final points = int.tryParse(_pointsController.text.trim()) ?? -1;

    if (name.isEmpty) {
      setState(() => _errorMessage = 'Please enter member name.');
      return;
    }
    if (userId.isEmpty) {
      setState(() => _errorMessage = 'Please enter User ID.');
      return;
    }
    if (!Member.isValidUserId(userId)) {
      setState(() => _errorMessage = 'User ID must be in A00001 format (letter + 5 digits).');
      return;
    }
    if (points < Member.minPoints || points > Member.maxPoints) {
      setState(() => _errorMessage = 'Points must be between 0 and 999,999.');
      return;
    }

    if (!widget.isTreeEmpty && (_selectedParentId == null || _selectedParentId!.isEmpty)) {
      setState(() => _errorMessage = 'Please select a parent member.');
      return;
    }

    Navigator.pop(context);
    widget.onConfirm(
      name: name,
      userId: userId,
      points: points,
      parentId: widget.isTreeEmpty ? null : _selectedParentId,
      position: widget.isTreeEmpty ? null : _selectedPosition,
    );
  }
}
