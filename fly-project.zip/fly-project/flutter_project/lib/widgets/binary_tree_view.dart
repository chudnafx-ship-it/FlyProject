import 'package:flutter/material.dart';
import '../models/member.dart';
import 'member_card.dart';

abstract class TreeLayoutItem {}

class MemberLayoutItem extends TreeLayoutItem {
  final Member member;
  final TreeLayoutItem? left;
  final TreeLayoutItem? right;

  MemberLayoutItem(this.member, this.left, this.right);
}

class SlotLayoutItem extends TreeLayoutItem {
  final Member parent;
  final String position;

  SlotLayoutItem(this.parent, this.position);
}

class BinaryTreeView extends StatefulWidget {
  final List<Member> members;
  final Map<String, Member> membersMap;
  final String? selectedMemberId;
  final String searchQuery;
  final bool isAdminMode;
  final Function(Member) onMemberClick;
  final Function(Member parent, String position) onAddChildClick;
  final VoidCallback onAddRootClick;

  const BinaryTreeView({
    super.key,
    required this.members,
    required this.membersMap,
    required this.selectedMemberId,
    required this.searchQuery,
    required this.isAdminMode,
    required this.onMemberClick,
    required this.onAddChildClick,
    required this.onAddRootClick,
  });

  @override
  State<BinaryTreeView> createState() => _BinaryTreeViewState();
}

class _BinaryTreeViewState extends State<BinaryTreeView> {
  double _zoomScale = 1.0;

  @override
  Widget build(BuildContext context) {
    if (widget.members.isEmpty) {
      return Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.account_tree, size: 56, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 16),
                const Text(
                  'Fly Project Tree is Empty',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.isAdminMode
                      ? 'Add the Root Member to start your binary tree.'
                      : 'Unlock Admin Mode to initialize the tree.',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
                if (widget.isAdminMode) ...[
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: widget.onAddRootClick,
                    icon: const Icon(Icons.add),
                    label: const Text('Add Root Member'),
                  ),
                ]
              ],
            ),
          ),
        ),
      );
    }

    final nonRootIds = <String>{};
    for (var m in widget.members) {
      if (m.leftChildId != null) nonRootIds.add(m.leftChildId!);
      if (m.rightChildId != null) nonRootIds.add(m.rightChildId!);
    }
    var roots = widget.members.where((m) => m.parentId == null || m.parentId!.isEmpty).toList();
    if (roots.isEmpty) {
      roots = widget.members.where((m) => !nonRootIds.contains(m.id)).toList();
    }

    return Stack(
      children: [
        InteractiveViewer(
          boundaryMargin: const EdgeInsets.all(300),
          minScale: 0.5,
          maxScale: 2.0,
          transformationController: TransformationController(
            Matrix4.identity()..scale(_zoomScale),
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 60),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Column(
                children: roots.map((root) {
                  final treeLayout = _buildTree(root, widget.membersMap, widget.isAdminMode, 0, 5);
                  return _buildBranchWidget(treeLayout);
                }).toList(),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: Card(
            elevation: 4,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.zoom_out, size: 20),
                  onPressed: () => setState(() => _zoomScale = (_zoomScale - 0.2).clamp(0.5, 2.0)),
                ),
                Text('${(_zoomScale * 100).toInt()}%', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                IconButton(
                  icon: const Icon(Icons.zoom_in, size: 20),
                  onPressed: () => setState(() => _zoomScale = (_zoomScale + 0.2).clamp(0.5, 2.0)),
                ),
                IconButton(
                  icon: const Icon(Icons.restart_alt, size: 20),
                  onPressed: () => setState(() => _zoomScale = 1.0),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  TreeLayoutItem _buildTree(
    Member current,
    Map<String, Member> map,
    bool isAdminMode,
    int depth,
    int maxDepth,
  ) {
    if (depth >= maxDepth) return MemberLayoutItem(current, null, null);

    final leftChild = current.leftChildId != null ? map[current.leftChildId] : null;
    final rightChild = current.rightChildId != null ? map[current.rightChildId] : null;

    final leftItem = leftChild != null
        ? _buildTree(leftChild, map, isAdminMode, depth + 1, maxDepth)
        : (isAdminMode ? SlotLayoutItem(current, Member.positionLeft) : null);

    final rightItem = rightChild != null
        ? _buildTree(rightChild, map, isAdminMode, depth + 1, maxDepth)
        : (isAdminMode ? SlotLayoutItem(current, Member.positionRight) : null);

    return MemberLayoutItem(current, leftItem, rightItem);
  }

  Widget _buildBranchWidget(TreeLayoutItem item) {
    if (item is SlotLayoutItem) {
      return EmptySlotCard(
        parentName: item.parent.name,
        position: item.position,
        onTap: () => widget.onAddChildClick(item.parent, item.position),
      );
    }

    final memberItem = item as MemberLayoutItem;
    final member = memberItem.member;
    final isSelected = member.id == widget.selectedMemberId;
    final isHighlighted = widget.searchQuery.isNotEmpty &&
        (member.userId.toLowerCase().contains(widget.searchQuery.toLowerCase()) ||
            member.name.toLowerCase().contains(widget.searchQuery.toLowerCase()));

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        MemberCard(
          member: member,
          isSelected: isSelected,
          isHighlighted: isHighlighted,
          onTap: () => widget.onMemberClick(member),
        ),
        if (memberItem.left != null || memberItem.right != null) ...[
          Container(
            width: 2,
            height: 20,
            color: Colors.grey.withOpacity(0.5),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (memberItem.left != null) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(
                    children: [
                      CustomPaint(
                        size: const Size(60, 20),
                        painter: BranchLinePainter(isLeft: true),
                      ),
                      _buildBranchWidget(memberItem.left!),
                    ],
                  ),
                ),
              ],
              if (memberItem.right != null) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Column(
                    children: [
                      CustomPaint(
                        size: const Size(60, 20),
                        painter: BranchLinePainter(isLeft: false),
                      ),
                      _buildBranchWidget(memberItem.right!),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ]
      ],
    );
  }
}

class BranchLinePainter extends CustomPainter {
  final bool isLeft;
  BranchLinePainter({required this.isLeft});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = isLeft ? const Color(0xFF3B82F6).withOpacity(0.8) : const Color(0xFF10B981).withOpacity(0.8)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();
    if (isLeft) {
      path.moveTo(size.width, 0);
      path.cubicTo(
        size.width * 0.7, size.height * 0.2,
        size.width * 0.3, size.height * 0.8,
        0, size.height,
      );
    } else {
      path.moveTo(0, 0);
      path.cubicTo(
        size.width * 0.3, size.height * 0.2,
        size.width * 0.7, size.height * 0.8,
        size.width, size.height,
      );
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
