import 'package:flutter/material.dart';
import '../models/member.dart';

class MemberDetailSheet extends StatelessWidget {
  final Member member;
  final Map<String, Member> membersMap;
  final bool isAdminMode;
  final VoidCallback onDismiss;
  final Function(String memberId) onNavigateToMember;
  final Function(Member member) onEditPointsClick;
  final Function(int delta) onQuickAdjustPoints;
  final Function(Member member) onEditMemberClick;
  final Function(Member parent, String position) onAddChildClick;
  final Function(Member member, bool cascade) onRemoveMemberClick;
  final VoidCallback onUnlockAdminClick;

  const MemberDetailSheet({
    super.key,
    required this.member,
    required this.membersMap,
    required this.isAdminMode,
    required this.onDismiss,
    required this.onNavigateToMember,
    required this.onEditPointsClick,
    required this.onQuickAdjustPoints,
    required this.onEditMemberClick,
    required this.onAddChildClick,
    required this.onRemoveMemberClick,
    required this.onUnlockAdminClick,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLeft = member.position == Member.positionLeft;
    final isRight = member.position == Member.positionRight;
    final posColor = isLeft
        ? const Color(0xFF3B82F6)
        : isRight
            ? const Color(0xFF10B981)
            : theme.colorScheme.primary;

    final progress = (member.points / Member.maxPoints).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: posColor.withOpacity(0.18),
                  child: Icon(Icons.person, color: posColor, size: 30),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        member.name.isEmpty ? 'Unnamed Member' : member.name,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.surfaceVariant,
                              borderRadius: BorderRadius.circular(5),
                              border: Border.all(color: theme.colorScheme.outlineVariant),
                            ),
                            child: Text(
                              'ID: ${member.userId}',
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontWeight: FontWeight.bold,
                                color: theme.colorScheme.primary,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: posColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Text(
                              isLeft ? 'Left Branch' : isRight ? 'Right Branch' : 'Tree Root',
                              style: TextStyle(color: posColor, fontWeight: FontWeight.w600, fontSize: 11),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.4)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.diamond, color: Color(0xFFF59E0B), size: 18),
                          SizedBox(width: 6),
                          Text('Virtual Score Points', style: TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                      Text(
                        '${Member.formatPoints(member.points)} / 999,999',
                        style: TextStyle(color: theme.colorScheme.onSurfaceVariant, fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    Member.formatPoints(member.points),
                    style: const TextStyle(
                      color: Color(0xFFF59E0B),
                      fontWeight: FontWeight.w900,
                      fontSize: 28,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress,
                      color: const Color(0xFFF59E0B),
                      backgroundColor: const Color(0xFFF59E0B).withOpacity(0.2),
                      minHeight: 8,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Binary Tree Connections',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(height: 8),
            if (member.parentId != null && member.parentId!.isNotEmpty) ...[
              _buildRelationTile(
                label: 'Parent',
                title: membersMap[member.parentId]?.name ?? 'Parent (${member.parentId})',
                subtitle: membersMap[member.parentId]?.userId ?? '',
                color: theme.colorScheme.primary,
                onTap: () => onNavigateToMember(member.parentId!),
              ),
            ] else ...[
              _buildRelationTile(
                label: 'Parent',
                title: 'Root Member (No Parent)',
                subtitle: 'Apex of Tournament Tree',
                color: theme.colorScheme.primary,
                onTap: null,
              ),
            ],
            const SizedBox(height: 6),
            if (member.leftChildId != null) ...[
              _buildRelationTile(
                label: 'Left Child',
                title: membersMap[member.leftChildId]?.name ?? 'Left Child',
                subtitle: membersMap[member.leftChildId] != null
                    ? '${membersMap[member.leftChildId]!.userId} • ${Member.formatPoints(membersMap[member.leftChildId]!.points)} pts'
                    : '',
                color: const Color(0xFF3B82F6),
                onTap: () => onNavigateToMember(member.leftChildId!),
              ),
            ] else ...[
              _buildVacantTile(
                position: Member.positionLeft,
                isAdminMode: isAdminMode,
                onAdd: () => onAddChildClick(member, Member.positionLeft),
              ),
            ],
            const SizedBox(height: 6),
            if (member.rightChildId != null) ...[
              _buildRelationTile(
                label: 'Right Child',
                title: membersMap[member.rightChildId]?.name ?? 'Right Child',
                subtitle: membersMap[member.rightChildId] != null
                    ? '${membersMap[member.rightChildId]!.userId} • ${Member.formatPoints(membersMap[member.rightChildId]!.points)} pts'
                    : '',
                color: const Color(0xFF10B981),
                onTap: () => onNavigateToMember(member.rightChildId!),
              ),
            ] else ...[
              _buildVacantTile(
                position: Member.positionRight,
                isAdminMode: isAdminMode,
                onAdd: () => onAddChildClick(member, Member.positionRight),
              ),
            ],
            const SizedBox(height: 20),
            if (isAdminMode) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: theme.colorScheme.primary.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.shield, color: theme.colorScheme.primary, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'Admin Actions',
                          style: TextStyle(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => onQuickAdjustPoints(1000),
                            child: const Text('+1,000 pts'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => onQuickAdjustPoints(-1000),
                            child: const Text('-1,000 pts'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF59E0B),
                          foregroundColor: Colors.black,
                        ),
                        onPressed: () => onEditPointsClick(member),
                        icon: const Icon(Icons.edit, size: 16),
                        label: const Text('Change Points (0 - 999,999)'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.tonal(
                            onPressed: () => onEditMemberClick(member),
                            child: const Text('Edit Info'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: theme.colorScheme.error,
                              foregroundColor: Colors.white,
                            ),
                            onPressed: () => _confirmDelete(context),
                            icon: const Icon(Icons.delete, size: 16),
                            label: const Text('Remove'),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceVariant,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.lock, size: 18),
                        SizedBox(width: 8),
                        Text('Admin PIN required to edit'),
                      ],
                    ),
                    TextButton(
                      onPressed: onUnlockAdminClick,
                      child: const Text('Unlock Admin'),
                    ),
                  ],
                ),
              )
            ],
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildRelationTile({
    required String label,
    required String title,
    required String subtitle,
    required Color color,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: color.withOpacity(0.18),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                label,
                style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (subtitle.isNotEmpty)
                    Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 11)),
                ],
              ),
            ),
            if (onTap != null) const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildVacantTile({
    required String position,
    required bool isAdminMode,
    required VoidCallback onAdd,
  }) {
    final posColor = position == Member.positionLeft ? const Color(0xFF3B82F6) : const Color(0xFF10B981);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: posColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: posColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '$position Child',
                  style: TextStyle(color: posColor, fontWeight: FontWeight.bold, fontSize: 11),
                ),
              ),
              const SizedBox(width: 12),
              const Text('Vacant Slot (Open)', style: TextStyle(color: Colors.grey)),
            ],
          ),
          if (isAdminMode)
            FilledButton.tonal(
              onPressed: onAdd,
              child: const Text('Add'),
            ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Member?'),
        content: Text('Are you sure you want to remove ${member.name} (${member.userId}) from the binary tree?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              onRemoveMemberClick(member, true);
            },
            child: const Text('Delete Subtree'),
          ),
        ],
      ),
    );
  }
}
