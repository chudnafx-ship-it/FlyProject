import 'package:flutter/material.dart';

class AdminPinDialog extends StatefulWidget {
  final bool Function(String pin) onUnlock;

  const AdminPinDialog({
    super.key,
    required this.onUnlock,
  });

  @override
  State<AdminPinDialog> createState() => _AdminPinDialogState();
}

class _AdminPinDialogState extends State<AdminPinDialog> {
  final _pinController = TextEditingController();
  bool _isError = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.shield, color: Colors.teal),
          SizedBox(width: 8),
          Text('Unlock Admin Privileges'),
        ],
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Enter Admin PIN to enable member management and point editing.',
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _pinController,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Admin PIN',
              hintText: 'Enter PIN',
              errorText: _isError ? 'Incorrect PIN. Try again.' : null,
            ),
            onChanged: (_) {
              if (_isError) setState(() => _isError = false);
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            final pin = _pinController.text.trim();
            final success = widget.onUnlock(pin);
            if (success) {
              Navigator.pop(context);
            } else {
              setState(() => _isError = true);
            }
          },
          child: const Text('Unlock'),
        ),
      ],
    );
  }
}
