import 'package:flutter/material.dart';
import '../models/member.dart';

class MemberCard extends StatelessWidget {
  final Member member;
  final bool isSelected;
  final bool isHighlighted;
  final VoidCallback onTap;

  const MemberCard({
    super.key,
    required this.member,
    required this.isSelected,
    required this.isHighlighted,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLeft = member.position == Member.positionLeft;
    final isRight = member.position == Member.positionRight;

    final branchColor = isLeft
        ? const Color(0xFF3B82F6)
        : isRight
            ? const Color(0xFF10B981)
            : theme.colorScheme.primary;

    final borderColor = isSelected
        ? theme.colorScheme.primary
        : isHighlighted
            ? const Color(0xFFF59E0B)
            : branchColor.withOpacity(0.5);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 175,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: isSelected
              ? theme.colorScheme.primaryContainer.withOpacity(0.4)
              : theme.colorScheme.surfaceVariant.withOpacity(0.6),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: borderColor,
            width: isSelected || isHighlighted ? 2.5 : 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 6,
              offset: const Offset(0, 2),
            )
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header Row: Position and User ID
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                  decoration: BoxDecoration(
                    color: branchColor.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text(
                    isLeft ? 'L-Child' : isRight ? 'R-Child' : 'ROOT',
                    style: TextStyle(
                      color: branchColor,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: theme.colorScheme.outlineVariant, width: 0.8),
                  ),
                  child: Text(
                    member.userId,
                    style: const TextStyle(
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Avatar Icon
            CircleAvatar(
              radius: 18,
              backgroundColor: branchColor.withOpacity(0.18),
              child: Icon(Icons.person, color: branchColor, size: 22),
            ),
            const SizedBox(height: 6),

            // Member Name
            Text(
              member.name.isEmpty ? 'Unnamed' : member.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            ),
            const SizedBox(height: 6),

            // Points Badge (0 - 999999)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.4)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.diamond, color: Color(0xFFF59E0B), size: 12),
                  const SizedBox(width: 4),
                  Text(
                    '${Member.formatPoints(member.points)} pts',
                    style: const TextStyle(
                      color: Color(0xFFB45309),
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EmptySlotCard extends StatelessWidget {
  final String parentName;
  final String position;
  final VoidCallback onTap;

  const EmptySlotCard({
    super.key,
    required this.parentName,
    required this.position,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLeft = position == Member.positionLeft;
    final posColor = isLeft ? const Color(0xFF3B82F6) : const Color(0xFF10B981);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 155,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface.withOpacity(0.6),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: posColor.withOpacity(0.45), width: 1.2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: posColor.withOpacity(0.15),
              child: Icon(Icons.add, color: posColor, size: 18),
            ),
            const SizedBox(height: 4),
            Text(
              '+ $position Child',
              style: TextStyle(color: posColor, fontWeight: FontWeight.bold, fontSize: 11),
            ),
            Text(
              'under $parentName',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: theme.colorScheme.onSurfaceVariant, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}
