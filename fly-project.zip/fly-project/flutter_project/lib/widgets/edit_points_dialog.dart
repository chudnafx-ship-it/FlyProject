import 'package:flutter/material.dart';
import '../models/member.dart';

class EditPointsDialog extends StatefulWidget {
  final Member member;
  final Function(int newPoints) onConfirm;

  const EditPointsDialog({
    super.key,
    required this.member,
    required this.onConfirm,
  });

  @override
  State<EditPointsDialog> createState() => _EditPointsDialogState();
}

class _EditPointsDialogState extends State<EditPointsDialog> {
  late int _pointsValue;
  late final TextEditingController _controller;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _pointsValue = widget.member.points;
    _controller = TextEditingController(text: _pointsValue.toString());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Column(
        children: [
          const Text('Modify Member Points', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text(
            '${widget.member.name} (${widget.member.userId})',
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Current:'),
                Text(
                  '${Member.formatPoints(_pointsValue)} pts',
                  style: const TextStyle(
                    color: Color(0xFFF59E0B),
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Points (0 - 999,999)',
                errorText: _errorMessage,
                helperText: 'Allowed range: 0 to 999,999 points',
              ),
              onChanged: (val) {
                final parsed = int.tryParse(val) ?? 0;
                if (parsed <= Member.maxPoints) {
                  setState(() {
                    _pointsValue = parsed;
                    _errorMessage = null;
                  });
                }
              },
            ),
            Slider(
              value: _pointsValue.toDouble().clamp(0.0, Member.maxPoints.toDouble()),
              min: 0,
              max: Member.maxPoints.toDouble(),
              activeColor: const Color(0xFFF59E0B),
              onChanged: (val) {
                setState(() {
                  _pointsValue = val.toInt();
                  _controller.text = _pointsValue.toString();
                  _errorMessage = null;
                });
              },
            ),
            const SizedBox(height: 8),
            const Text('Quick Adjustments:', style: TextStyle(fontSize: 11, color: Colors.grey)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _buildChip('+100', 100),
                _buildChip('+500', 500),
                _buildChip('+1,000', 1000),
                _buildChip('+10,000', 10000),
                _buildChip('-500', -500),
                _buildChip('-1,000', -1000),
                ActionChip(
                  label: const Text('Reset 0', style: TextStyle(fontSize: 11)),
                  onPressed: () {
                    setState(() {
                      _pointsValue = 0;
                      _controller.text = '0';
                    });
                  },
                ),
                ActionChip(
                  label: const Text('Max', style: TextStyle(fontSize: 11)),
                  onPressed: () {
                    setState(() {
                      _pointsValue = Member.maxPoints;
                      _controller.text = Member.maxPoints.toString();
                    });
                  },
                ),
              ],
            )
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFF59E0B),
            foregroundColor: Colors.black,
          ),
          onPressed: () {
            if (_pointsValue < Member.minPoints || _pointsValue > Member.maxPoints) {
              setState(() => _errorMessage = 'Points must be 0 to 999,999');
              return;
            }
            Navigator.pop(context);
            widget.onConfirm(_pointsValue);
          },
          child: const Text('Save Points'),
        ),
      ],
    );
  }

  Widget _buildChip(String label, int delta) {
    return ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 11)),
      onPressed: () {
        setState(() {
          _pointsValue = (_pointsValue + delta).clamp(Member.minPoints, Member.maxPoints);
          _controller.text = _pointsValue.toString();
        });
      },
    );
  }
}
