import 'package:flutter/material.dart';
import '../models/member.dart';

enum SortOption { points, userId, name }

class HierarchyListView extends StatefulWidget {
  final List<Member> members;
  final Map<String, Member> membersMap;
  final String searchQuery;
  final Function(Member) onMemberClick;

  const HierarchyListView({
    super.key,
    required this.members,
    required this.membersMap,
    required this.searchQuery,
    required this.onMemberClick,
  });

  @override
  State<HierarchyListView> createState() => _HierarchyListViewState();
}

class _HierarchyListViewState extends State<HierarchyListView> {
  SortOption _sortOption = SortOption.points;

  @override
  Widget build(BuildContext context) {
    final query = widget.searchQuery.trim().toLowerCase();
    var list = widget.members.where((m) {
      if (query.isEmpty) return true;
      return m.userId.toLowerCase().contains(query) || m.name.toLowerCase().contains(query);
    }).toList();

    switch (_sortOption) {
      case SortOption.points:
        list.sort((a, b) => b.points.compareTo(a.points));
        break;
      case SortOption.userId:
        list.sort((a, b) => a.userId.compareTo(b.userId));
        break;
      case SortOption.name:
        list.sort((a, b) => a.name.compareTo(b.name));
        break;
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${list.length} Member${list.length != 1 ? 's' : ''}',
                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
              ),
              Row(
                children: [
                  ChoiceChip(
                    label: const Text('Highest Points', style: TextStyle(fontSize: 11)),
                    selected: _sortOption == SortOption.points,
                    onSelected: (selected) {
                      if (selected) setState(() => _sortOption = SortOption.points);
                    },
                  ),
                  const SizedBox(width: 6),
                  ChoiceChip(
                    label: const Text('User ID', style: TextStyle(fontSize: 11)),
                    selected: _sortOption == SortOption.userId,
                    onSelected: (selected) {
                      if (selected) setState(() => _sortOption = SortOption.userId);
                    },
                  ),
                  const SizedBox(width: 6),
                  ChoiceChip(
                    label: const Text('Name', style: TextStyle(fontSize: 11)),
                    selected: _sortOption == SortOption.name,
                    onSelected: (selected) {
                      if (selected) setState(() => _sortOption = SortOption.name);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? Center(
                  child: Text(
                    query.isEmpty ? 'No members found' : 'No matches for "$query"',
                    style: const TextStyle(color: Colors.grey),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final member = list[index];
                    final isLeft = member.position == Member.positionLeft;
                    final isRight = member.position == Member.positionRight;
                    final posColor = isLeft
                        ? const Color(0xFF3B82F6)
                        : isRight
                            ? const Color(0xFF10B981)
                            : Theme.of(context).colorScheme.primary;

                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: posColor.withOpacity(0.18),
                          child: Icon(Icons.person, color: posColor),
                        ),
                        title: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.surfaceVariant,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                member.userId,
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                member.name.isEmpty ? 'Unnamed' : member.name,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        subtitle: Text(
                          isLeft
                              ? 'Left Branch Child'
                              : isRight
                                  ? 'Right Branch Child'
                                  : 'Root Member',
                          style: TextStyle(fontSize: 11, color: posColor),
                        ),
                        trailing: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF59E0B).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.4)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.diamond, color: Color(0xFFF59E0B), size: 14),
                              const SizedBox(width: 4),
                              Text(
                                Member.formatPoints(member.points),
                                style: const TextStyle(
                                  color: Color(0xFFB45309),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        onTap: () => widget.onMemberClick(member),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
