import 'package:flutter/material.dart';
import '../models/member.dart';
import '../services/firestore_service.dart';
import '../widgets/binary_tree_view.dart';
import '../widgets/hierarchy_list_view.dart';
import '../widgets/member_detail_sheet.dart';
import '../widgets/add_member_dialog.dart';
import '../widgets/edit_points_dialog.dart';
import '../widgets/admin_pin_dialog.dart';

class MainScreen extends StatefulWidget {
  final FirestoreService firestoreService;

  const MainScreen({super.key, required this.firestoreService});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final TextEditingController _searchController = TextEditingController();

  bool _isAdminMode = false;
  final String _adminPin = '123369';
  String _searchQuery = '';
  String? _selectedMemberId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    widget.firestoreService.seedInitialDataIfEmpty();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: theme.colorScheme.primary.withOpacity(0.18),
              child: Icon(Icons.account_tree, color: theme.colorScheme.primary, size: 18),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Fly Project',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
                Text(
                  'Binary Tree & Points Network',
                  style: TextStyle(fontSize: 10, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: ActionChip(
              avatar: Icon(
                _isAdminMode ? Icons.shield : Icons.visibility,
                size: 14,
                color: _isAdminMode ? theme.colorScheme.primary : Colors.grey,
              ),
              label: Text(
                _isAdminMode ? 'Admin Active' : 'Viewer Mode',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: _isAdminMode ? theme.colorScheme.primary : Colors.grey,
                ),
              ),
              backgroundColor: _isAdminMode ? theme.colorScheme.primary.withOpacity(0.12) : null,
              onPressed: () {
                if (_isAdminMode) {
                  setState(() => _isAdminMode = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Switched to Viewer Mode')),
                  );
                } else {
                  _showAdminPinDialog();
                }
              },
            ),
          ),
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: _showAboutDialog,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(105),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by User ID (A00001) or Name...',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              setState(() => _searchQuery = '');
                            },
                          )
                        : null,
                    filled: true,
                    fillColor: theme.colorScheme.surfaceVariant.withOpacity(0.4),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  onChanged: (val) => setState(() => _searchQuery = val),
                ),
              ),
              TabBar(
                controller: _tabController,
                tabs: const [
                  Tab(icon: Icon(Icons.account_tree, size: 18), text: 'Tree Visualizer'),
                  Tab(icon: Icon(Icons.format_list_bulleted, size: 18), text: 'Directory List'),
                ],
              ),
            ],
          ),
        ),
      ),
      body: StreamBuilder<List<Member>>(
        stream: widget.firestoreService.streamMembers(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Text('Error loading tree: ${snapshot.error}'),
            );
          }

          final members = snapshot.data ?? [];
          final membersMap = {for (var m in members) m.id: m};

          final parentCandidates = members.where((m) {
            return m.leftChildId == null || m.rightChildId == null;
          }).toList();

          var maxNum = 0;
          for (var m in members) {
            final num = Member.parseUserIdNumber(m.userId);
            if (num != null && num > maxNum) maxNum = num;
          }
          final suggestedUserId = Member.nextFormattedUserId(maxNum);

          return TabBarView(
            controller: _tabController,
            children: [
              BinaryTreeView(
                members: members,
                membersMap: membersMap,
                selectedMemberId: _selectedMemberId,
                searchQuery: _searchQuery,
                isAdminMode: _isAdminMode,
                onMemberClick: (member) {
                  _showMemberDetailSheet(member, membersMap);
                },
                onAddChildClick: (parent, position) {
                  _showAddMemberDialog(
                    parentCandidates: parentCandidates,
                    suggestedUserId: suggestedUserId,
                    isTreeEmpty: members.isEmpty,
                    initialParent: parent,
                    initialPosition: position,
                  );
                },
                onAddRootClick: () {
                  _showAddMemberDialog(
                    parentCandidates: parentCandidates,
                    suggestedUserId: suggestedUserId,
                    isTreeEmpty: true,
                  );
                },
              ),
              HierarchyListView(
                members: members,
                membersMap: membersMap,
                searchQuery: _searchQuery,
                onMemberClick: (member) {
                  _showMemberDetailSheet(member, membersMap);
                },
              ),
            ],
          );
        },
      ),
      floatingActionButton: _isAdminMode
          ? FloatingActionButton.extended(
              onPressed: () {
                _showAddMemberDialog(
                  parentCandidates: [],
                  suggestedUserId: 'A00001',
                  isTreeEmpty: false,
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Member'),
            )
          : null,
    );
  }

  void _showMemberDetailSheet(Member member, Map<String, Member> membersMap) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => MemberDetailSheet(
        member: member,
        membersMap: membersMap,
        isAdminMode: _isAdminMode,
        onDismiss: () => Navigator.pop(ctx),
        onNavigateToMember: (id) {
          Navigator.pop(ctx);
          final target = membersMap[id];
          if (target != null) {
            _showMemberDetailSheet(target, membersMap);
          }
        },
        onEditPointsClick: (m) {
          Navigator.pop(ctx);
          _showEditPointsDialog(m);
        },
        onQuickAdjustPoints: (delta) async {
          final newPts = (member.points + delta).clamp(Member.minPoints, Member.maxPoints);
          await widget.firestoreService.updatePoints(member.id, newPts);
          if (mounted) Navigator.pop(ctx);
        },
        onEditMemberClick: (m) {
          Navigator.pop(ctx);
          _showEditMemberDialog(m);
        },
        onAddChildClick: (parent, pos) {
          Navigator.pop(ctx);
          _showAddMemberDialog(
            parentCandidates: [parent],
            suggestedUserId: 'A00001',
            isTreeEmpty: false,
            initialParent: parent,
            initialPosition: pos,
          );
        },
        onRemoveMemberClick: (m, cascade) async {
          await widget.firestoreService.removeMember(m.id, cascade: cascade);
          if (mounted) Navigator.pop(ctx);
        },
        onUnlockAdminClick: () {
          Navigator.pop(ctx);
          _showAdminPinDialog();
        },
      ),
    );
  }

  void _showAddMemberDialog({
    required List<Member> parentCandidates,
    required String suggestedUserId,
    required bool isTreeEmpty,
    Member? initialParent,
    String? initialPosition,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => AddMemberDialog(
        parentCandidates: parentCandidates,
        suggestedUserId: suggestedUserId,
        isTreeEmpty: isTreeEmpty,
        initialParent: initialParent,
        initialPosition: initialPosition,
        onConfirm: ({
          required String name,
          required String userId,
          required int points,
          String? parentId,
          String? position,
        }) async {
          try {
            await widget.firestoreService.addMember(
              userId: userId,
              name: name,
              points: points,
              parentId: parentId,
              position: position,
            );
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Member $userId ($name) added successfully')),
              );
            }
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Failed to add member: $e')),
              );
            }
          }
        },
      ),
    );
  }

  void _showEditPointsDialog(Member member) {
    showDialog(
      context: context,
      builder: (ctx) => EditPointsDialog(
        member: member,
        onConfirm: (newPoints) async {
          await widget.firestoreService.updatePoints(member.id, newPoints);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Points updated to ${Member.formatPoints(newPoints)}')),
            );
          }
        },
      ),
    );
  }

  void _showEditMemberDialog(Member member) {
    final nameCtrl = TextEditingController(text: member.name);
    final ptsCtrl = TextEditingController(text: member.points.toString());

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Member Info'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ptsCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Points (0 - 999,999)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final newName = nameCtrl.text.trim();
              final newPts = int.tryParse(ptsCtrl.text.trim()) ?? member.points;
              Navigator.pop(ctx);
              await widget.firestoreService.updateMember(member.id, newName, newPts);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showAdminPinDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AdminPinDialog(
        onUnlock: (pin) {
          if (pin.trim() == _adminPin) {
            setState(() => _isAdminMode = true);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Admin Mode activated. You can now edit points and members.')),
            );
            return true;
          }
          return false;
        },
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('About Fly Project'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Fly Project is an administrative and tournament member management system backed by Firebase Firestore.'),
            SizedBox(height: 8),
            Text('• Computer Science Binary Tree: Each member has at most 2 children (Left & Right).'),
            Text('• Public Viewer: Anyone can view and search without login.'),
            Text('• Admin Mode: Protected by Admin PIN to add/remove members and modify points.'),
            Text('• Formatted IDs: A00001 format with virtual ranking score points (0 - 999,999).'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Got it')),
        ],
      ),
    );
  }
}
