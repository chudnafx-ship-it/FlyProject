import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/main_screen.dart';
import 'services/firestore_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint('Firebase initialization notice: $e');
  }
  runApp(const FlyProjectApp());
}

class FlyProjectApp extends StatelessWidget {
  const FlyProjectApp({super.key});

  @override
  Widget build(BuildContext context) {
    const primaryCyan = Color(0xFF00687A);
    const secondarySlate = Color(0xFF4A6267);
    const tertiaryGold = Color(0xFFF59E0B);

    return MaterialApp(
      title: 'Fly Project',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primaryCyan,
          secondary: secondarySlate,
          tertiary: tertiaryGold,
          brightness: Brightness.light,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4FD8EB),
          secondary: const Color(0xFFB1CBD0),
          tertiary: tertiaryGold,
          brightness: Brightness.dark,
        ),
      ),
      home: MainScreen(
        firestoreService: FirestoreService(),
      ),
    );
  }
}
