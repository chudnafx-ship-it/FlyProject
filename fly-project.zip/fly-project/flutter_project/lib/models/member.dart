import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class Member {
  static const String positionLeft = 'LEFT';
  static const String positionRight = 'RIGHT';
  static const int minPoints = 0;
  static const int maxPoints = 999999;

  final String id;
  final String userId;
  final String name;
  final int points;
  final String? parentId;
  final String? position; // 'LEFT' or 'RIGHT'
  final String? leftChildId;
  final String? rightChildId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Member({
    required this.id,
    required this.userId,
    required this.name,
    required this.points,
    this.parentId,
    this.position,
    this.leftChildId,
    this.rightChildId,
    this.createdAt,
    this.updatedAt,
  });

  factory Member.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return Member(
      id: doc.id,
      userId: (data['userId'] as String? ?? '').trim(),
      name: (data['name'] as String? ?? '').trim(),
      points: (data['points'] as num? ?? 0).toInt().clamp(minPoints, maxPoints),
      parentId: data['parentId'] as String?,
      position: data['position'] as String?,
      leftChildId: data['leftChildId'] as String?,
      rightChildId: data['rightChildId'] as String?,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'name': name,
      'points': points.clamp(minPoints, maxPoints),
      'parentId': parentId,
      'position': position,
      'leftChildId': leftChildId,
      'rightChildId': rightChildId,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    };
  }

  static String formatPoints(int pts) {
    final formatter = NumberFormat('#,###');
    return formatter.format(pts.clamp(minPoints, maxPoints));
  }

  static bool isValidUserId(String id) {
    return RegExp(r'^[A-Za-z]\d{5}$').hasMatch(id.trim());
  }

  static int? parseUserIdNumber(String id) {
    final match = RegExp(r'^[A-Za-z](\d{5})$').firstMatch(id.trim());
    if (match != null) {
      return int.tryParse(match.group(1)!);
    }
    return null;
  }

  static String nextFormattedUserId(int maxNum, {String prefix = 'A'}) {
    final next = (maxNum + 1).clamp(1, 99999);
    return '$prefix${next.toString().padLeft(5, '0')}';
  }
}
